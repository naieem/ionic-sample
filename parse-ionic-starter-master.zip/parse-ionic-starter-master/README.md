# parse-ionic-starter
Parse Ionic Starter Demo with Calling Normal JS SDK &amp; also calling Cloud Function
