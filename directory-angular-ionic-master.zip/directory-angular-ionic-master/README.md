# Employee Directory #

A sample application built with Ionic and AngularJS

More information here: http://coenraets.org